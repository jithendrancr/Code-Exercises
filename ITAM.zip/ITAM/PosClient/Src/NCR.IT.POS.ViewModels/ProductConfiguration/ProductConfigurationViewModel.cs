﻿using NCR.IT.Client.POS.BusinessObjects.CommandHandlers.ProductConfiguration;
using NCR.IT.Client.POS.BusinessObjects.DataModels.ProductConfiguration;
using Retalix.Client.POS.Presentation.ViewModels.ViewModels;
using Retalix.Client.Presentation.Core.Command;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using NCR.IT.Contracts.Generated.ProductConfiguration;

namespace NCR.IT.Client.POS.ViewsModels.ProductConfiguration
{
    public class ProductConfigurationViewModel : PosViewModelBase
    {
        private IProductConfigurationDataModel _productConfigurationDataModel;
        public ICommand BackCommand { get; private set; }

        private List<ProductConfigurationType> _productConfigurationElement;
        public List<ProductConfigurationType> ProductConfigurationElement
        {
            get { return _productConfigurationElement; }
            set { _productConfigurationElement = value; }
        }

        public ProductConfigurationViewModel()
        {
            Init();
            InitCommands();
        }

        private void Init()
        {
            _productConfigurationDataModel = _dataModelProvider.GetDataModel<IProductConfigurationDataModel>();
            var productConfigurationList = new List<ProductConfigurationType>();
            var productConfigurationObj=_productConfigurationDataModel.productConfigurationLookupResponse.ProductConfigurationType;
            productConfigurationList.AddRange(productConfigurationObj);
            ProductConfigurationElement = productConfigurationList;
        }


        private void InitCommands()
        {
            BackCommand = new CommandAction<object>(ExecuteBackCommand, x => true);
        }

        protected virtual void ExecuteBackCommand(object obj)
        {

            ExecuteBackCommandHandler();
        }

        protected virtual void ExecuteBackCommandHandler()
        {
            var command = CommandHandlerFactory.Create<IProductConfigurationBackCommandHandler>();
            ExecuteCommandHandlerAndStartFlow(command);
        }
    }
}
