﻿using Retalix.Client.POS.Presentation.ViewModels.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Retalix.Client.Presentation.Core.Command;
using NCR.IT.Client.POS.BusinessObjects.CommandHandlers.ProductConfiguration;

namespace NCR.IT.Client.POS.ViewsModels.ProductConfiguration
{
    public class ProductConfigurationInputViewModel : PosViewModelBase
    {
        public ICommand GetCommand{ get; private set; }
        public ICommand BackCommand{ get; private set; }


        private int _id;
        public int ProductConfigurationId
        {
            get { return _id; }
            set
            {
                _id = value;
                NotifyPropertyChanged("ProductConfigurationId");
            }
        }

        public ProductConfigurationInputViewModel()
        {
            Init(); 
        }
        
        private void Init()
        {
            InitCommands();
        }

        private void InitCommands()
        {
            GetCommand = new CommandAction<object>(ExecuteGetCommand, CanExecuteGetCommand);
            BackCommand = new CommandAction<object>(ExecuteBackCommand, x=>true);


        }

        private bool CanExecuteGetCommand(object obj)
        {
            return ProductConfigurationId >= 0;
        }

        protected virtual void ExecuteGetCommand(object obj)
        {

            ExecuteProductConfigurationLookupCommandHandler(_id);
        }

        protected virtual void ExecuteBackCommand(object obj)
        {

            ExecuteBackCommandHandler();
        }

        protected virtual void ExecuteProductConfigurationLookupCommandHandler(int productConfigurationId)
        {
            var command = CommandHandlerFactory.Create<IProductConfigurationLookupCommandHandler>();
            command.Init(productConfigurationId);
            ExecuteCommandHandlerAndStartFlow(command);
        }

        protected virtual void ExecuteBackCommandHandler()
        {
            var command = CommandHandlerFactory.Create<IProductConfigurationBackCommandHandler>();
            ExecuteCommandHandlerAndStartFlow(command);
        }
    }
}
