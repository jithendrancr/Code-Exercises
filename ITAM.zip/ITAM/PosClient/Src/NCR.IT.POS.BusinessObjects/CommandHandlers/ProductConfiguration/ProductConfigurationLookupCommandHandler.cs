﻿using NCR.IT.Client.POS.BusinessObjects.DataModels.ProductConfiguration;
using NCR.IT.Client.POS.BusinessObjects.ServiceAgents.ProductConfiguration.Service_Agent;
using NCR.IT.Contracts.Generated.ProductConfiguration;
using Retalix.Client.POS.BusinessObjects.CommandHandlers;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCR.IT.Client.POS.BusinessObjects.CommandHandlers.ProductConfiguration
{
    [Export(typeof(IProductConfigurationLookupCommandHandler))]
    public class ProductConfigurationLookupCommandHandler : PosCommandHandlerBase, IProductConfigurationLookupCommandHandler
    {
        private int _productConfigurationId;
        private const string ProductConfigurationLookupOutcome = "ProductConfigurationLookupOutcome";

        public void Init(int productConfigurationId)
        {
            _productConfigurationId = productConfigurationId;
        }

        protected override string ExecuteLogic()
        {
            var productConfigurationLookupResponse = ExecuteProductConfigurationLookupServiceAgent();
            SetupProductConfigurationDataModel(productConfigurationLookupResponse);
            return ProductConfigurationLookupOutcome;
        }

        private void SetupProductConfigurationDataModel(ProductConfigurationLookupResponse productConfigurationLookupResponse)
        {
            var productConfigurationDataModel = GetDataModel<IProductConfigurationDataModel>();
            productConfigurationDataModel.productConfigurationLookupResponse = productConfigurationLookupResponse;
        }

        private ProductConfigurationLookupResponse ExecuteProductConfigurationLookupServiceAgent()
        {
            var productConfigurationLookupServiceAgent = GetServiceAgent<IProductConfigurationLookupServiceAgent>();
            return productConfigurationLookupServiceAgent.Execute(_productConfigurationId);
        }
    }
}
