﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Retalix.Client.POS.BusinessObjects.CommandHandlers;

namespace NCR.IT.Client.POS.BusinessObjects.CommandHandlers.ProductConfiguration
{
    [Export(typeof(IProductConfigurationBackCommandHandler))]
    public class ProductConfigurationBackCommandHandler : PosCommandHandlerBase, IProductConfigurationBackCommandHandler
    {
        private const string ProductConfigurationBackOutcome = "ProductConfigurationBackOutcome";

        protected override string ExecuteLogic()
        {
            return ProductConfigurationBackOutcome;
        }
    }
}
