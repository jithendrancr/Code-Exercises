﻿using Retalix.Client.Common.Handlers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCR.IT.Client.POS.BusinessObjects.CommandHandlers.ProductConfiguration
{
    public interface IProductConfigurationLookupCommandHandler : ICommandHandler
    {
        void Init(int productConfigurationId);
    }
}
