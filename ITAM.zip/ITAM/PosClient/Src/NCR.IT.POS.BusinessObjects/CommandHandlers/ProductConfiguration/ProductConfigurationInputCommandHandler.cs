﻿using Retalix.Client.POS.BusinessObjects.CommandHandlers;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCR.IT.Client.POS.BusinessObjects.CommandHandlers.ProductConfiguration
{
    [Export(typeof(IProductConfigurationInputCommandHandler))]
    public class ProductConfigurationInputCommandHandler : PosCommandHandlerBase, IProductConfigurationInputCommandHandler
    {
        private const string ProductConfigurationInputOutcome = "ProductConfigurationInputOutcome";

        protected override string ExecuteLogic()
        {
            return ProductConfigurationInputOutcome;
        }
    }
}
