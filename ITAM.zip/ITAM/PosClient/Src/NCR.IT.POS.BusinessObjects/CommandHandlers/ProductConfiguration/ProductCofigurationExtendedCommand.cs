﻿using Retalix.Client.Common.Handlers;
using Retalix.Client.POS.BusinessObjects.Factory;
using Retalix.Client.Presentation.Core.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCR.IT.Client.POS.BusinessObjects.CommandHandlers.ProductConfiguration
{
    [Export(typeof(IExtendedCommand))]
    public class ProductCofigurationExtendedCommand : IExtendedCommand
    {
        private const string ProductConfigurationCommandName = "ProductConfigurationDetails";

        [Import]
        private ICommandHandlerFactory _commandHandlerFactory;
        public string CommandName { get { return ProductConfigurationCommandName; } }

        public ICommandHandler GetCommandHandler(ViewModelBase viewModel)
        {
            var commandHandler = _commandHandlerFactory.Create<IProductConfigurationInputCommandHandler>();
            return commandHandler;
        }
    }
}
