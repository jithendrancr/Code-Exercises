﻿using NCR.IT.Contracts.Generated.ProductConfiguration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCR.IT.Client.POS.BusinessObjects.ServiceAgents.ProductConfiguration.Service
{
    public interface IProductConfigurationLookupService
    {
        ProductConfigurationLookupResponse Execute(ProductConfigurationLookupRequest request);
    }
}
