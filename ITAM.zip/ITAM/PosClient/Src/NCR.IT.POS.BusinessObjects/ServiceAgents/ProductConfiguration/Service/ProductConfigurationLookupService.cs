﻿using NCR.IT.Contracts.Generated.ProductConfiguration;
using Retalix.Client.POS.API.Infrastructure.Service;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Retalix.Contracts.Generated.ProductAvailability;

namespace NCR.IT.Client.POS.BusinessObjects.ServiceAgents.ProductConfiguration.Service
{
    [Export(typeof(IProductConfigurationLookupService))]
    public class ProductConfigurationLookupService : ServiceBase, IProductConfigurationLookupService
    {
        private const string ServiceName = "ProductConfigurationLookup";
        public ProductConfigurationLookupResponse Execute(ProductConfigurationLookupRequest request)
        {
            return Execute<ProductConfigurationLookupRequest, ProductConfigurationLookupResponse>(request, ServiceName);
        }
    }
}