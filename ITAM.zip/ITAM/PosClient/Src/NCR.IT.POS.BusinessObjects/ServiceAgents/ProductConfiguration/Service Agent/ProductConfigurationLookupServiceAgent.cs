﻿using NCR.IT.Client.POS.BusinessObjects.ServiceAgents.ProductConfiguration.Service;
using Retalix.Client.Common.ServiceAgents;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NCR.IT.Client.POS.BusinessObjects.ServiceAgents.ProductConfiguration.Builder;
using NCR.IT.Contracts.Generated.ProductConfiguration;
using NCR.IT.Client.POS.BusinessObjects.ServiceAgents.ProductConfiguration.Validator;

namespace NCR.IT.Client.POS.BusinessObjects.ServiceAgents.ProductConfiguration.Service_Agent
{
    [Export(typeof(IServiceAgent))]
    class ProductConfigurationLookupServiceAgent : IProductConfigurationLookupServiceAgent
    {
        [Import]
        private IProductConfigurationLookupService _productConfigurationLookupService;

        [Import]
        private IProductConfigurationLookupValidator _productConfigurationLookupValidator;

        [Import]
        private IProductConfigurationLookupRequestBuilder _productConfigurationLookupRequestBuilder;


        public ProductConfigurationLookupResponse Execute(int productConfigurationId)
        {
            var productConfigurationLookupRequest = _productConfigurationLookupRequestBuilder.BuildLookupRequest(productConfigurationId);
            var productConfigurationLookupResponse = _productConfigurationLookupService.Execute(productConfigurationLookupRequest);
            _productConfigurationLookupValidator.Validate(productConfigurationLookupRequest, productConfigurationLookupResponse);
            // ClientLog.ClientBusinessFlows.Debug("Test Log {0}", new BusinessException());
            return productConfigurationLookupResponse;
        }
    }
}
