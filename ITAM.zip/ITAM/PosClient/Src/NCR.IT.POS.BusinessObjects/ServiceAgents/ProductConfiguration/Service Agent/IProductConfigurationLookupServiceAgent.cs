﻿using Retalix.Client.Common.ServiceAgents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NCR.IT.Contracts.Generated.ProductConfiguration;

namespace NCR.IT.Client.POS.BusinessObjects.ServiceAgents.ProductConfiguration.Service_Agent
{
    public interface IProductConfigurationLookupServiceAgent : IServiceAgent
    {
        ProductConfigurationLookupResponse Execute(int productConfigurationId);
    }
}
