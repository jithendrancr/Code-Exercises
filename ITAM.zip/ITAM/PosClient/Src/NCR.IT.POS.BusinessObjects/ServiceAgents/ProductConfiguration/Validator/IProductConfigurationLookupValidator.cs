﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NCR.IT.Contracts.Generated.ProductConfiguration;

namespace NCR.IT.Client.POS.BusinessObjects.ServiceAgents.ProductConfiguration.Validator
{
    public interface IProductConfigurationLookupValidator
    {
        void Validate(ProductConfigurationLookupRequest request, ProductConfigurationLookupResponse response);
    }
}
