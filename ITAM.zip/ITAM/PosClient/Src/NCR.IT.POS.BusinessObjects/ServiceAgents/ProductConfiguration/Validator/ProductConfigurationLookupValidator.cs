﻿using Retalix.Client.POS.BusinessObjects.ServiceAgents.Validations;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NCR.IT.Contracts.Generated.ProductConfiguration;

namespace NCR.IT.Client.POS.BusinessObjects.ServiceAgents.ProductConfiguration.Validator
{
    [Export(typeof(IProductConfigurationLookupValidator))]
    public class ProductConfigurationLookupValidator : RetalixValidatorBase, IProductConfigurationLookupValidator
    {
        public void Validate(ProductConfigurationLookupRequest request, ProductConfigurationLookupResponse response)
        {
            ValidateResponseError(response.Header);
        }
    }
}