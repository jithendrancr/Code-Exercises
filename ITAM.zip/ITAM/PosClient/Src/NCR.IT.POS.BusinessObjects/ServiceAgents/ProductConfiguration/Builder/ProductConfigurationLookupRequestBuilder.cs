﻿using NCR.IT.Contracts.Generated.ProductConfiguration;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Retalix.Client.CommonServices.Utils;
using Retalix.Contracts.Generated.Arts.PosLogV6.Source;
using Retalix.Contracts.Generated.Common;

namespace NCR.IT.Client.POS.BusinessObjects.ServiceAgents.ProductConfiguration.Builder
{
    [Export(typeof(IProductConfigurationLookupRequestBuilder))]
    public class ProductConfigurationLookupRequestBuilder : IProductConfigurationLookupRequestBuilder
    {
        public ProductConfigurationLookupRequest BuildLookupRequest(int productConfigurationId)
        {
            //var carSearchCriteria = new ProductConfigurationSearchCriteriaType { MakerName = makerName };
            var carLookupRequest = new ProductConfigurationLookupRequest()
            {
                Header = new RetalixCommonHeaderType()
                {
                    MessageId = new RequestIDCommonData()
                    {
                        Value = MessageIdGenerator.GetId().ToString()
                    }
                },
                Id = productConfigurationId

            };
            return carLookupRequest;
        }
    }
}