﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NCR.IT.Contracts.Generated.ProductConfiguration;

namespace NCR.IT.Client.POS.BusinessObjects.ServiceAgents.ProductConfiguration.Builder
{
    public interface IProductConfigurationLookupRequestBuilder
    {
        ProductConfigurationLookupRequest BuildLookupRequest(int productConfigurationId);
    }
}
