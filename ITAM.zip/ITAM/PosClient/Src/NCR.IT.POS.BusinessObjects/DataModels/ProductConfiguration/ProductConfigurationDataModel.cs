﻿using Retalix.Client.Common.DataModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NCR.IT.Contracts.Generated.ProductConfiguration;

namespace NCR.IT.Client.POS.BusinessObjects.DataModels.ProductConfiguration
{
    [Export(typeof(IDataModel))]
    public class ProductConfigurationDataModel : IProductConfigurationDataModel
    {
        public ProductConfigurationLookupResponse productConfigurationLookupResponse { get; set; }

        public void Clear()
        {
            productConfigurationLookupResponse = null;
        }
    }
}
