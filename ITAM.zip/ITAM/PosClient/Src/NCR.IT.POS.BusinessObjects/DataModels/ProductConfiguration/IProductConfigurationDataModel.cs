﻿using NCR.IT.Contracts.Generated.ProductConfiguration;
using Retalix.Client.Common.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCR.IT.Client.POS.BusinessObjects.DataModels.ProductConfiguration
{
    public interface IProductConfigurationDataModel : IDataModel
    {
        ProductConfigurationLookupResponse productConfigurationLookupResponse { get; set; }
    }
}
