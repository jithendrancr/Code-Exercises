﻿using NCR.IT.Server.Model.Exceptions;
using Retalix.StoreServices.Model.Infrastructure.Exceptions;

namespace NCR.IT.Server.BundleItem.Exceptions
{
    public class InvalidProductConfigurationRequest : BusinessException
    {
        public InvalidProductConfigurationRequest(string message)
            : base(message, ErrorCodes.ProductConfigurationExceptionErrorCode)
        {
        }
    }
}
