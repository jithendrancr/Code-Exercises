﻿using NCR.IT.Server.Model.BundleItem;
using NCR.IT.Server.Model.RegistrationAttributes;
using NCR.IT.Contracts.Generated.ProductConfiguration;

namespace NCR.IT.Server.BundleItem.Convertors
{
    [RegisterAddition]
    public class ProductConfigurationModelToContract : IProductConfigurationModelToContract
    {
        public ProductConfigurationType Convert(IProductConfiguration productConfiguration)
        {
            var productConfigurationType =  new ProductConfigurationType
            {
                Id = productConfiguration != null ? productConfiguration.Id : 0,
                Code = productConfiguration != null ? productConfiguration.Code : string.Empty,
                Description = productConfiguration != null ? productConfiguration.Description : string.Empty,
            };
            return productConfigurationType;
        }
    }
}
