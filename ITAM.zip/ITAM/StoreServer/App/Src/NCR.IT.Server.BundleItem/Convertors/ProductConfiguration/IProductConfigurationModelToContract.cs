﻿using NCR.IT.Contracts.Generated.ProductConfiguration;
using NCR.IT.Server.Model.BundleItem;

namespace NCR.IT.Server.BundleItem.Convertors
{
    public interface IProductConfigurationModelToContract
    {
        ProductConfigurationType Convert(IProductConfiguration productConfiguration);
    }
}
