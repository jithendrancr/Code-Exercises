﻿using NCR.IT.Server.Model.BundleItem;
using NCR.IT.Server.Model.RegistrationAttributes;
using NCR.IT.Contracts.Generated.ProductConfiguration;

namespace NCR.IT.Server.BundleItem.Convertors
{
    [RegisterAddition]
    public class ProductConfigurationContractToModel : IProductConfigurationContractToModel
    {
        private readonly IProductConfigurationFactory _productConfigurationFactory;
        public ProductConfigurationContractToModel(IProductConfigurationFactory bundleItemFactory)
        {
            _productConfigurationFactory = bundleItemFactory;

        }
        public IProductConfiguration Convert(ProductConfigurationType productConfiguration)
        {
            if (productConfiguration != null)
            {
                var id = productConfiguration.Id;
                var code = productConfiguration.Code;
                var description = productConfiguration.Description;
                return _productConfigurationFactory.CreateProductConfiguration(id, code, description);
            }
            return null;
        }
        
    }
}
