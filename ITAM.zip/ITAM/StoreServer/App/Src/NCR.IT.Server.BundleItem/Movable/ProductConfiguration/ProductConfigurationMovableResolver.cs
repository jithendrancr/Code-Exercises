﻿using NCR.IT.Server.BundleItem.Model.ProductConfiguration;
using NCR.IT.Server.Common;
using NCR.IT.Server.Model.RegistrationAttributes;
using Retalix.StoreServices.Model.Infrastructure.DataMovement;
using Retalix.StoreServices.Model.Infrastructure.DataMovement.Versioning;

namespace NCR.IT.Server.BundleItem.Movable.ProductConfiguration
{
    [RegisterAddition(Id = "ProductConfiguration", ImplInterfaceType = typeof(IMovableServicesResolver))]
    public class ProductConfigurationMovableResolver : ICompatibilityMovableServicesResolver
    {
        private readonly IProductConfigurationMovableDao _movableDao;
        private readonly IProductConfigurationEntityToDtoMapper _entityToDtoMapper;
        private readonly IProductConfigurationMovableFormatter _movableFormatter;

        public ProductConfigurationMovableResolver(IProductConfigurationMovableDao movableDao, IProductConfigurationEntityToDtoMapper entityToDtoMapper, 
            IProductConfigurationMovableFormatter movableFormatter)
        {
            _movableDao = movableDao;
            _entityToDtoMapper = entityToDtoMapper;
            _movableFormatter = movableFormatter;
        }

        public IMovableFormatter Formatter
        {
            get { return _movableFormatter; }
        }
        public IMovableDao MovableDao
        {
            get { return _movableDao; }
        }

        public IEntityToDtoMapper EntityToDtoMapper
        {
            get { return _entityToDtoMapper; }
        }
        public string ComponentName
        {
            get { return Constants.Movable.ComponentName; }
        }

    }
}
