﻿using System;
using System.Collections.Generic;
using System.Linq;
using NCR.IT.Server.Model.RegistrationAttributes;
using Retalix.StoreServices.Model.Infrastructure.DataMovement;
using Retalix.StoreServices.Model.Infrastructure.UnitOfWork;
using NCR.IT.Server.BundleItem.Model.ProductConfiguration;

namespace NCR.IT.Server.BundleItem.Movable.ProductConfiguration
{
    [RegisterAddition]
    public class ProductConfigurationMovableEntityToDtoConvertor : IProductConfigurationMovableEntityToDtoConvertor
    {
        public IMovable[] MapBackFromDto(IEnumerable<INamedObject> dtos, DataChangeType changeType)
        {
            if (dtos == null)
                return Enumerable.Empty<IMovable>() as IMovable[];

            return dtos.Cast<BusinessComponents.ProductConfiguration.ProductConfiguration>().Select(ToMovable).ToArray();
        }

        public INamedObject[] MapToDto(IEnumerable<IMovable> movables, DataChangeType changeType)
        {
            if (movables == null)
                return Enumerable.Empty<INamedObject>() as INamedObject[];

            return null;
            //movables.Select(ToDto).ToArray();
        }

        public Type DtoType()
        {
            return typeof(BusinessComponents.ProductConfiguration.ProductConfiguration);
        }

        protected IMovable ToMovable(BusinessComponents.ProductConfiguration.ProductConfiguration dto)
        {
            return null;
            //dto;
        }

        protected BusinessComponents.ProductConfiguration.ProductConfiguration ToDto(IMovable movable)
        {
            var dto = movable as BusinessComponents.ProductConfiguration.ProductConfiguration;
            return dto;
        }
    }
}
