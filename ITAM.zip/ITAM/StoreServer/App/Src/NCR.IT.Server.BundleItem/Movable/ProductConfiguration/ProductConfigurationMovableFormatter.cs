﻿using System.Collections.Generic;
using System.Linq;
using System.Xml;
using NCR.IT.Server.Common;
using NCR.IT.Server.Model.RegistrationAttributes;
using Retalix.StoreServices.Model.Infrastructure.DataMovement;
using NCR.IT.Server.BundleItem.Model.ProductConfiguration;

namespace NCR.IT.Server.BundleItem.Movable.ProductConfiguration
{
    [RegisterAddition]
    public class ProductConfigurationMovableFormatter : IProductConfigurationMovableFormatter
    {
        public IEnumerable<XmlDocument> Serialize(IEnumerable<IMovable> movables)
        {
            return movables.Select(movable => movable.ToXmlDocument());
        }

        public IEnumerable<IMovable> Deserialize(IEnumerable<XmlDocument> contracts)
        {
            return null;
                //contracts.Select(contract => contract.InnerXml.Deserialize<BusinessComponents.ProductConfiguration.ProductConfiguration>()).ToList();
        }
    }
}
