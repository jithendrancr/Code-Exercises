﻿using System;
using System.Collections.Generic;
using Common.Logging;
using NCR.IT.Server.Common.BusinessComponents;
using NCR.IT.Server.Model.BundleItem;
using NCR.IT.Server.Model.RegistrationAttributes;
using Retalix.StoreServices.Model.Infrastructure.DataMovement;
using Retalix.StoreServices.Model.Infrastructure.DataMovement.Filter;
using Retalix.StoreServices.Model.Organization.BusinessUnit;

namespace NCR.IT.Server.BundleItem.Movable.ProductConfiguration
{
    [RegisterAddition]
    public class ProductConfigurationDmsFilter : IDmsFilter
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(ProductConfigurationDmsFilter));
        private readonly IBusinessUnitDao _businessUnitDao;
        public ProductConfigurationDmsFilter(IBusinessUnitDao businessUnitDao)
        {
            Logger.Debug(msg=>msg("ProductConfigurationDmsFilter::Inovke ProductConfigurationDmsFilter"));
            _businessUnitDao = businessUnitDao;
        }
        public IEnumerable<IBusinessUnit> GetRelevantBusinessUnits(IMovable entity)
        {
            Logger.Debug(msg=>msg("ProductConfigurationDmsFilter::GetRelevantBusinessUnits:"));
            var ProductConfiguration = entity as IProductConfiguration;
            if (ProductConfiguration != null)
            {
                //var businessUnit = _businessUnitDao.Get(ProductConfiguration.Id.ToString());
                var businessUnit = _businessUnitDao.Get("001002");
                Logger.Debug(msg=>msg("ProductConfigurationDmsFilter::BusinessUsnit:{0}",businessUnit));
                return new List<IBusinessUnit> { businessUnit };
            }
            return new List<IBusinessUnit>();
        }

        public bool IsRelevant(IMovable entity)
        {
            return entity is IProductConfiguration;
        }
    }
}
