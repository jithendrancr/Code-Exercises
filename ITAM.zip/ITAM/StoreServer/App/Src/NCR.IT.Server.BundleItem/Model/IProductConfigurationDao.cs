﻿using NCR.IT.Server.Model.BundleItem;
using System.Collections.Generic;

namespace NCR.IT.Server.BundleItem.Model
{
    public interface IProductConfigurationDao
    {
        void SaveOrUpdate(IProductConfiguration entity);
        IEnumerable<IProductConfiguration> GetAll(); 
        IProductConfiguration GetProductConfigurationById(int id);
        void Delete(IProductConfiguration entity);
    }
}
