﻿using Retalix.StoreServices.Model.Product.Versioning;

namespace NCR.IT.Server.BundleItem.Model.ProductConfiguration
{
    public interface IProductConfigurationMovableEntityToDtoConvertor : IMovableEntityToDtoConvertor
    {
    }
}
