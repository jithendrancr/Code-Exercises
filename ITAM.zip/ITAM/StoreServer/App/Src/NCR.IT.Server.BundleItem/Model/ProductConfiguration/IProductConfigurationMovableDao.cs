﻿using Retalix.StoreServices.Model.Infrastructure.DataMovement;

namespace NCR.IT.Server.BundleItem.Model.ProductConfiguration
{
    public interface IProductConfigurationMovableDao : IMovableDao
    {

    }
}
