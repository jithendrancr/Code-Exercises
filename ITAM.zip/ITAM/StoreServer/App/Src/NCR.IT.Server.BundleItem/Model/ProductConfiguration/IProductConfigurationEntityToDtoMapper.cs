﻿using Retalix.StoreServices.Model.Infrastructure.DataMovement.Versioning;

namespace NCR.IT.Server.BundleItem.Model.ProductConfiguration
{
    public interface IProductConfigurationEntityToDtoMapper : IEntityToDtoMapper
    {
    }
}
