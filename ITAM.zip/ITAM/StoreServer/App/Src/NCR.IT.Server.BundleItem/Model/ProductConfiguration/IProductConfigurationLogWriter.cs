﻿using System.Collections.Generic;
using Retalix.StoreServices.Model.Infrastructure.Audit;
using Retalix.StoreServices.Model.Selling;
using Retalix.StoreServices.Model.Selling.RetailTransaction.RetailTransactionLog;

namespace NCR.IT.Server.BundleItem.Model.ProductConfiguration
{
    public interface IProductConfigurationLogWriter
    {
        void Write(IRetailTransactionLogDocumentWriter writer, IRetailTransaction retailTransaction, IEnumerable<AuditLog> productConfigurationAuditLogs);
    }
}
