﻿using NCR.IT.Server.Model.BundleItem;
using ProtoBuf;
using System;

namespace NCR.IT.Server.BundleItem.BusinessComponents.ProductConfiguration
{
    [Serializable]
    [ProtoContract]
    public class ProductConfiguration : IProductConfiguration 
    {
        private const string EntityNameKey = "ProductConfiguration";

        [ProtoMember(1)]
        public int Id { get; set; }
        [ProtoMember(2)]
        public string Code { get; set; }
        [ProtoMember(3)]
        public string Description { get; set; }

        [ProtoMember(4)]
        public string EntityName
        {
            get { return EntityNameKey; }
            set { }
        }


        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != typeof(BundleItem)) return false;
            return Equals((BundleItem)obj);

        }

        protected bool Equals(ProductConfiguration other)
        {
            if (ReferenceEquals(null, other)) return false;
            return ReferenceEquals(this, other) || IsParamsEquals(other);
        }

        private bool IsParamsEquals(IProductConfiguration other)
        {
            return string.Equals(Id, other.Id);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                var result = Id > 0 ? Id.GetHashCode() : 0;
                result = result * 397 ^ (Code != null ? Code.GetHashCode() : 0);
                result = result * 397 ^ (Description != null ? Description.GetHashCode() : 0);
                return result;
            }
        }
    }
}
