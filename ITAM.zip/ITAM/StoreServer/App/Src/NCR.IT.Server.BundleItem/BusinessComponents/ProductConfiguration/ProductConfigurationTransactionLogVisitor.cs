﻿using System;
using System.Linq;
using Common.Logging;
using NCR.IT.Server.Common;
using NCR.IT.Server.Common.Model;
using NCR.IT.Server.Model.RegistrationAttributes;
using NCR.IT.Server.Model.TransactionLog;
using Retalix.StoreServices.Model.Infrastructure.Audit;
using Retalix.StoreServices.Model.Selling;
using NCR.IT.Server.BundleItem.Model.ProductConfiguration;

namespace NCR.IT.Server.BundleItem.BusinessComponents.ProductConfiguration
{
    [RegisterAddition]
    public class ProductConfigurationTransactionLogVisitor : TransactionLogVisitorBase
    {
        private readonly IAuditLogDao _auditLogDao;
        private readonly IProductConfigurationLogWriter _productConfigurationLogWriter;
        private static readonly ILog Logger = LogManager.GetLogger(typeof(ProductConfigurationTransactionLogVisitor));

        public ProductConfigurationTransactionLogVisitor(IAuditLogDao auditLogDao, IProductConfigurationLogWriter productConfigurationLogWriter)
        {
            _auditLogDao = auditLogDao;
            _productConfigurationLogWriter = productConfigurationLogWriter;
        }

        public override void Visit(IRetailTransactionLogExtendedVisitor extendedVisitor)
        {
            Logger.Debug("ProductConfigurationTLogVisitor::Visit");
            var retailTransaction = extendedVisitor.RetailTransaction;
            var productConfigurationAuditLogs = _auditLogDao.GetAll();
            if (productConfigurationAuditLogs != null && productConfigurationAuditLogs.Any())
            {
                Logger.Debug("ProductConfigurationTLogVisitor::Visit found bill payment audit logs - related nodes will be added to Tlog");
                _productConfigurationLogWriter.Write(extendedVisitor.Writer, retailTransaction, productConfigurationAuditLogs);
            }
        }
    }
}