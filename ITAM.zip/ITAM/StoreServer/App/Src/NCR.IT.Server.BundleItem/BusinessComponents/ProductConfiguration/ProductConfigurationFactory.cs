﻿using NCR.IT.Server.Model.BundleItem;
using NCR.IT.Server.Model.RegistrationAttributes;

namespace NCR.IT.Server.BundleItem.BusinessComponents
{
    [RegisterAddition]
    public class ProductConfigurationFactory : IProductConfigurationFactory
    {
        public IProductConfiguration CreateProductConfiguration(int Id, string Code, string Description)
        {
            return new ProductConfiguration.ProductConfiguration
            {
                Id = Id,
                Code = Code,
                Description = Description
            };
        }
        
    }
}
