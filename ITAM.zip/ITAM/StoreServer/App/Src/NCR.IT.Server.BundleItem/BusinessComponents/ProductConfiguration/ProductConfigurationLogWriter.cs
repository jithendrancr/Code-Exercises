﻿using System;
using System.Collections.Generic;
using System.Xml;
using Common.Logging;
using Retalix.Contract.Schemas.Schema.ARTS.PosLog_V6.Objects;
using Retalix.Contract.Schemas.Schema.ARTS.PosLog_V6.Objects.SchemaObjects;
using Retalix.Contract.Schemas.Schema.ARTS.PosLog_V6.Objects.SpecialImplementation;
using Retalix.Contracts.Extensions;
using NCR.IT.Server.Common;
using NCR.IT.Server.Model.RegistrationAttributes;
using Retalix.StoreServices.Model.Infrastructure.Audit;
using Retalix.StoreServices.Model.Selling;
using Retalix.StoreServices.Model.Selling.CustomerOrder.Line.Audit;
using Retalix.StoreServices.Model.Selling.RetailTransaction.RetailTransactionLog;
using NCR.IT.Server.BundleItem.Model.ProductConfiguration;

namespace NCR.IT.Server.ProductConfiguration.BusinessComponents
{
    [RegisterAddition]
    public class ProductConfigurationLogWriter : IProductConfigurationLogWriter
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof (ProductConfigurationLogWriter));

        private readonly R10Extension _r10Extension = new R10Extension();

        private DateTime _retailTransactionStartTime;
        private  DateTime _retailTransactionEndTime;

        public void Write(IRetailTransactionLogDocumentWriter writer, IRetailTransaction retailTransaction, IEnumerable<AuditLog> productConfigurationAuditLogs)
        {
            Logger.Debug("ProductConfigurationLogWriter:Write");
            
            var artsTransaction = (TransactionDomainSpecific)writer.ObjectContent;
            var retailTransactionLog = artsTransaction.GetMainRetailTransaction();
            _retailTransactionStartTime = retailTransaction.StartTime;
            _retailTransactionEndTime = retailTransaction.EndTime;
            foreach (var audit in productConfigurationAuditLogs)
            {
                var productConfigurationNode = BuildLine(audit);
                retailTransactionLog.LineItem.Add(productConfigurationNode);
            }
            retailTransactionLog.Any = new List<XmlElement> { GetTimeDifference() };
            artsTransaction.Any = new List<XmlElement> { GetTimeDifference() };
            writer.UpdateArtsTransaction(artsTransaction); 
        }

      
        private XmlElement GetTimeDifference()
        {
            var timeDifferenceelemntElement = _r10Extension.CreateXmlElement("TransactionTime");
            TimeSpan timeDifference = _retailTransactionEndTime - _retailTransactionStartTime;
            timeDifferenceelemntElement.InnerText = timeDifference.ToString();
            return timeDifferenceelemntElement;
        }
        private LineItemDomainSpecific BuildLine(AuditLog auditLog)
        {
            return new LineItemDomainSpecific
            {
                BeginDateTime = new DateTimeCommonData { Value = DateTime.SpecifyKind(_retailTransactionStartTime, DateTimeKind.Local), ValueSpecified = true },
                BeginDateTimeSpecified = true,
                EndDateTime = new DateTimeCommonData { Value = DateTime.SpecifyKind(_retailTransactionEndTime, DateTimeKind.Local), ValueSpecified = true },
                EndDateTimeSpecified = true,
                Any = new List<XmlElement> {  GetTimeDifference() }
               
            };
        }
    }
}

