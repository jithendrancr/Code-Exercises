﻿using System.Linq;
using Common.Logging;
using NCR.IT.Server.BundleItem.Convertors;
using NCR.IT.Server.BundleItem.Model;
using NCR.IT.Server.Common;
using Retalix.StoreServices.Model.Infrastructure.Service;
using NCR.IT.Server.Model.RegistrationAttributes;
using NCR.IT.Contracts.Generated.ProductConfiguration;
using NCR.IT.Server.Common.BusinessServices;
using NCR.IT.Server.Model.BundleItem;
using Common.Logging;
using NCR.IT.Contracts.Generated.BundleItem;
using NCR.IT.Server.BundleItem.Convertors;
using NCR.IT.Server.BundleItem.Exceptions;
using NCR.IT.Server.BundleItem.Model;
using NCR.IT.Server.Common;
using Retalix.StoreServices.Model.Infrastructure.Service;
using NCR.IT.Server.Model.RegistrationAttributes;

namespace NCR.IT.Server.BundleItem.BusinessServices
{
    [RegisterService] 
    public class ProductConfigurationLookupService : BusinessServiceBase<ProductConfigurationLookupRequest, ProductConfigurationLookupResponse>
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(ProductConfigurationLookupService));
        private IProductConfiguration _productConfiguration;
        private readonly IProductConfigurationDao _productConfigurationDao;
        private readonly IProductConfigurationModelToContract _productConfigurationModelToContract;
        private ProductConfigurationType[] _productConfigurationType;

        public ProductConfigurationLookupService(IProductConfigurationDao productConfigurationDao, IProductConfigurationModelToContract productConfigurationModelToContract)
        {
            _productConfigurationDao = productConfigurationDao;
            _productConfigurationModelToContract = productConfigurationModelToContract;
        }

        protected override void InternalExecute()
        {
            Logger.Debug("ProductConfigurationLookupService called");

            if (Request == null) return;

            if (Request.Id > 0)
            {
               var productConfiguration = _productConfigurationDao.GetProductConfigurationById(Request.Id);
               var productConfigurationContract = _productConfigurationModelToContract.Convert(productConfiguration);
               _productConfigurationType = new ProductConfigurationType[1]{productConfigurationContract};
            }
            else
            {
                var productConfigurationAll = _productConfigurationDao.GetAll();
                _productConfigurationType = productConfigurationAll.Select(_productConfigurationModelToContract.Convert).ToArray();
            }

            Logger.Debug(string.Format("ProductConfigurationLookupService call ended"));
        }

        protected override IDocumentResponse BuildResponse(ProductConfigurationLookupResponse response)
        {
            response.ProductConfigurationType = _productConfigurationType;
            return new DocumentResponse(response);
        }
    }
}
