﻿using System;
using Common.Logging;
using Retalix.Contracts.Generated.Common;
using NCR.IT.Server.BundleItem.Convertors;
using NCR.IT.Server.BundleItem.Exceptions;
using NCR.IT.Server.BundleItem.Model;
using NCR.IT.Server.Common;
using NCR.IT.Server.Model.RegistrationAttributes;
using NCR.IT.Contracts.Generated.ProductConfiguration;
using System.Linq;
using Common.Logging;
using NHibernate.Linq;
using NCR.IT.Contracts.Generated.BundleItem;
using NCR.IT.Server.Model.BundleItem;
using Retalix.DPOS.SystemIntegrity;
using Retalix.StoreServices.Model.Infrastructure.Globalization;
using Retalix.StoreServices.Model.Infrastructure.Legacy.Bulk;
using Retalix.StoreServices.Model.Organization.BusinessUnit;
using Retalix.StoreServices.Model.Price;
using Retalix.StoreServices.Model.Product;
using Retalix.StoreServices.Model.Product.StoreRange;
using NCR.IT.Server.Model.Infrastructure.Servers;

namespace NCR.IT.Server.BundleItem.BusinessServices
{
    [RegisterService]
    public class ProductConfigurationMaintenanceService : BusinessServiceBase<ProductConfigurationMaintenanceRequest, ProductConfigurationMaintenanceResponse>
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(ProductConfigurationMaintenanceService));

        private readonly IProductConfigurationDao _productConfigurationDao;
        private readonly IProductConfigurationContractToModel _productConfigurationContractToModel;
        private ActionTypeCodes _action;

        public ProductConfigurationMaintenanceService(IProductConfigurationDao productConfigurationDao, IProductConfigurationContractToModel productConfigurationContractToModel)
        {
            _productConfigurationDao = productConfigurationDao;
            _productConfigurationContractToModel = productConfigurationContractToModel;
        }

        protected override void InternalExecute()
        {
            if (Request == null || Request.ProductConfigurationType == null) return;

            var productConfigurationTypes = Request.ProductConfigurationType;
            foreach (var productConfigurationType in productConfigurationTypes)
            {
                ExecuteAction(productConfigurationType);
            }
        }

        public void ExecuteAction(ProductConfigurationType ProductConfigurationType)
        {
            _action = GetAction(ProductConfigurationType);
            ValidateInput(ProductConfigurationType);

            var productConfiguration = _productConfigurationContractToModel.Convert(ProductConfigurationType);

            Logger.Debug(msg => msg(("ProductConfigurationMaintenanceService called with action {0}"), Enum.GetName(typeof(ActionTypeCodes), _action)));

            switch (_action)
            {
                case ActionTypeCodes.Add:
                case ActionTypeCodes.AddOrUpdate:
                case ActionTypeCodes.AddUpdate:
                case ActionTypeCodes.Update:
                    _productConfigurationDao.SaveOrUpdate(productConfiguration);
                    break;
                case ActionTypeCodes.Delete:
                    _productConfigurationDao.Delete(productConfiguration);
                    break;
            }

        }

        private bool IsUpdateAction(ActionTypeCodes action)
        {
            return (action == ActionTypeCodes.Add || action == ActionTypeCodes.AddOrUpdate ||
                    action == ActionTypeCodes.AddUpdate || action == ActionTypeCodes.Update);
        }

        private bool IsDeleteAction(ActionTypeCodes action)
        {
            return (action == ActionTypeCodes.Delete);
        }

        private ActionTypeCodes GetAction(ProductConfigurationType ProductConfigurationType)
        {
            return ProductConfigurationType.ActionSpecified ? ProductConfigurationType.Action : ActionTypeCodes.AddOrUpdate;
        }

        private void ValidateInput(ProductConfigurationType productConfigurationType)
        {
            if (string.IsNullOrWhiteSpace(productConfigurationType.Code))
                throw new InvalidProductConfigurationRequest("Could not save ProductConfiguration - missing Code");

            if (string.IsNullOrWhiteSpace(productConfigurationType.Description))
                throw new InvalidProductConfigurationRequest("Could not save ProductConfiguration - missing Description");
            
            if (IsDeleteAction(_action) && productConfigurationType.Id<1)
                throw new InvalidProductConfigurationRequest("Record Not Found");
        }
    }


}
