﻿using Common.Logging;
using NCR.IT.Server.BundleItem.Model;
using NCR.IT.Server.Model.BundleItem;
using NCR.IT.Server.Model.RegistrationAttributes;
using NHibernate;
using NHibernate.Criterion;
using NHibernate.Linq;
using Retalix.StoreServices.Model.Infrastructure.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using NCR.IT.Server.BundleItem.Exceptions;
using NCR.IT.Server.Common.Utils;
using Retalix.StoreServices.Model.Infrastructure.DataMovement;
using Retalix.StoreServices.Model.Infrastructure.DataMovement.DeleteAllProviders;

namespace NCR.IT.Server.BundleItem.Connectivity
{
    [RegisterAddition]
    public class ProductConfigurationDao : IProductConfigurationDao
    {
        private readonly ISessionProvider _sessionProvider;

        private ISession Session
        {
            get { return _sessionProvider.GetDefaultSession<ISession>(); }
        }

        private static readonly ILog Log = LogManager.GetCurrentClassLogger();

        public ProductConfigurationDao(ISessionProvider sessionProvider)
        {
            _sessionProvider = sessionProvider;
        }
        public IProductConfiguration GetProductConfigurationById(int id)
        {
            Log.Info(message => message("ProductConfigurationDao.GetProductConfigurationById : entered"));
            var criteria = Session.CreateCriteria(typeof(IProductConfiguration))
                .Add(Restrictions.Eq("Id", id));
            var result = criteria.List<IProductConfiguration>();
            if (result.Count > 0)
            {
                return result.FirstOrDefault();
            }
            else
            {
                throw new InvalidProductConfigurationRequest("Product Configuration Not Found. Please check Input");
            }
        }

        public IEnumerable<IProductConfiguration> GetAll()
        {
            Log.Info(message => message("ProductConfigurationDao.GetAll : entered"));

            List<IProductConfiguration> records = Session.Query<IProductConfiguration>().ToList();
            return records;
        }
        public void SaveOrUpdate(IProductConfiguration entity)
        {
            Log.Info(message => message("ProductConfigurationDao.SaveOrUpdate : entered"));
            try
            {
                Session.SaveOrUpdate(entity);
                Session.Flush();
            }
            catch (Exception e)
            {
                Log.Error("ProductConfigurationDao.SaveOrUpdate", e);
                throw e;
            }
        }

        public void Delete(IProductConfiguration entity)
        {
            Log.Info(message => message("ProductConfigurationDao.Delete : entered"));

            try
            {
                IProductConfiguration iProductConfiguration = GetProductConfigurationById(entity.Id);
                Session.Delete(iProductConfiguration);
                Session.Flush();
            }
            catch (Exception e)
            {
                Log.Error("ProductConfigurationDao.Delete", e);
                throw e;
            }
        }
    }
}
