﻿using NCR.IT.Server.Model.Annotations;
using System.Diagnostics.CodeAnalysis;
namespace NCR.IT.Server.Model.Exceptions
{
    [UsedImplicitly]
    public class ErrorCodes
    {
        public const string TouchPointExtensionStateNotFoundException = "TouchPointExtensionStateNotFoundException";
        public const string TouchPointCurrentlyBusyException = "TouchPointCurrentlyBusyException";
        public const string ScanInTransferFailureException = "ScanInTransferFailureException";
        public const string DriveNameAlreadyMappedException = "DriveNameAlreadyMappedException";
        public const string MappingNotFoundException = "MappingNotFoundException";
        public const string SocketConnectionException = "SocketConnectionException";
        public const string CmcResponseFailedVerificationException = "CmcResponseFailedVerificationException";
        public const string XmlParsingException = "XmlParsingException";

        public const string CardNotRecognized = "CardNotRecognized";
        public const string DateOfBirthIncorrect = "DateOfBirthIncorrect";
        public const string CardNotValid = "CardNotValid";
        public const string GpsOffline = "GpsOffline";
        public const string MissingParameter = "MissingParameter";
        public const string CustomerAlreadyExists = "CustomerAlreadyExists";
        public const string UsernameAlreadyExists = "UsernameAlreadyExists";
        public const string InvalidDataPattern = "InvalidDataPattern";
        public const string InvalidCustomerLoyaltyCard = "InvalidCustomerLoyaltyCard";
        public const string NotUnicoopFirenze = "NotUnicoopFirenze";
        public const string CustomerNotExistInCdm = "CustomerNotExistInCdm";
        public const string LoyUnsuccessfulResponse = "LoyUnsuccessfulResponse";
        public const string DisplayLoyUnsuccessfulResponse = "DisplayLoyUnsuccessfulResponse";
        public const string LoyInvalidCard = "LoyInvalidCard";
        public const string DisplayLoyInvalidCard = "DisplayLoyInvalidCard";
        public const string InvalidAdditionalCard = "InvalidAdditionalCard";
        public const string DisplayInvalidAdditionalCard = "DisplayInvalidAdditionalCard";
        public const string LoyOffline = "LoyOffline";
        public const string DisplayLoyOffline = "DisplayLoyOffline";
        public const string LoyaltySystemUnavailable = "LoyaltySystemUnavailable";
        public const string LeanInvoiceSystemUnavailable = "LeanInvoiceSystemUnavailable";
        public const string LeanInvoiceCustomerNotFound = "LeanInvoiceCustomerNotFound";
        public const string LeanInvoiceCustomerMismatch = "LeanInvoiceCustomerMismatch";
        public const string LeanInvoiceMissingDataInResponse = "LeanInvoiceMissingDataInResponse";
        public const string LeanInvoiceMissingDataInRequest = "LeanInvoiceMissingDataInRequest";
        public const string LeanInvoiceNotFiscalCode = "LeanInvoiceNotFiscalCode";
        public const string LeanInvoiceNoValidItemFound = "LeanInvoiceNoValidItemFound";
        public const string LeanInvoiceCustomerRequiredForFallback = "LeanInvoiceCustomerRequiredForFallback";
        public const string LeanInvoiceThirdPartyException = "LeanInvoiceThirdPartyException";
        public const string LeanInvoiceAutomaticLookupFailed = "LeanInvoiceAutomaticLookupFailed";
        public const string SystemParameterNotFound = "SystemParameterNotFound";
        public const string SystemParameterValueNotValid = "SystemParameterValueNotValid";
        public const string TokenExpierd = "TokenExpierd";
        public const string TokenNotFound = "TokenNotFound";
        public const string CustomerNotFound = "CustomerNotFound";
        public const string CreateCustomerActionFailed = "CreateCustomerActionFailed";
        public const string ResetPasswordNotAllowd = "ResetPasswordNotAllowd";
        public const string BirthDateNotValid = "BirthDateNotValid";
        public const string CannotAddSameCard = "CannotAddSameCard";
        public const string CannotAddMainCard = "CannotAddMainCard";
        public const string MaxAdditionalCardsReached = "MaxAdditionalCardsReached";
        public const string CustomerLoyaltyToRetailerMismatch = "CustomerLoyaltyToRetailerMismatch";
        public const string AlreadyAllocatedSco = "AlreadyAllocated";
        public const string M100DidntTriggerPromotion = "M100DidntTriggerPromotion";
        public const string PriceNotFoundForScaleBag = "PriceNotFoundForScaleBag";
        public const string InvalidEotBarcode = "InvalidEotBarcode";
        public const string RepeatAmountEmbeddedLineItem_Error = "RepeatAmountEmbeddedLineItem_Error";
        public const string AmountEmbeddedLineItemWithQuantity_Error = "AmountEmbeddedLineItemWithQuantity_Error";
        public const string RepeatInNotRepeatedGroupException = "RepeatInNotRepeatedGroup";
        public const string WEAuthorizerCommunicationException = "WEAuthorizerCommunicationException";



        //Bill Payment
        public const string ExceptionErrorCode = "BillPaymentRejected";

        //ScaleBag
        public const string VoidedItemPartOfScaleBagException = "VoidedItemPartOfScaleBag";
        public const string VoidScaleBasketException = "VoidScaleBasketException";
        public const string ScaleBagItemZeroQuantityException = "ScaleBagItemZeroQuantity";
        public const string ScaleBagItemZeroPriceException = "ScaleBagItemZeroPriceException";
        public const string ScaleBagNotFoundException = "ScaleBagNotFound";
        public const string SellingScaleBagException = "SellingScaleBagException";

        //ScaleBasket
        public const string ScaleBasketNotFoundException = "ScaleBasketNotFound";
        public const string ScaleBasketAlreadyInUseException = "ScaleBasketAlreadyInUse";
        public const string ScaleBasketAlreadySoldException = "ScaleBasketAlreadySold";
        public const string SellingScaleBasketException = "SellingScaleBasketException";

        //ShopNow
        public const string TransctionEndOfTripInProgressException = "TransctionEndOfTripInProgress";
        public const string CannotOpenNewTransactionForCustomerException = "CannotOpenNewTransactionForCustomerException";
        public const string NoConfigurationForStoreException = "NoConfigurationForStore";
        public const string LoyCardNotFoundException = "LoyCardNotFound";
        public const string LoyCardNotEnabledException = "LoyCardNotEnabledException";
        public const string LoyOfflineException = "LoyOffline";

        //Data Logic
        public const string DataLogicRetriesExceededException = "DataLogicRetriesExceededException";

        //SignUp
        public const string SignupWithFiscalException = "SignupWithFiscalException";


        //Business Exception Error Codes
        public const string InvalidQuantityEntered = "InvalidQuantityEntered";
        public const string NoMainCustomerCard = "NoMainCustomerCard";
        public const string RetailerNotValidForCoop = "RetailerNotValidForCoop";
        public const string BusinessUnitIsNotStore = "BusinessUnitIsNotStore";

        // Bundletem
        public const string BundleItemExceptionErrorCode = "BundleItemException";
        public const string BundleItemNotAllowedErrorCode = "BundleItemNotAllowed";
        public const string BundleItemConfigurationError = "BundleItemConfigurationError";

        //RecommendedApps
        public const string RecommendedAppsExceptionErrorCode = "RecommendedAppsException";

        //Notification
        public const string TransactionClosedException = "TransactionClosedException";

        //Store Services
        public const string StoreServicesException = "StoreServicesException";

        //EndOfTrip
        public const string TLogTransmissionFailure = "TLogTransmissionFailure";
        public const string EndOfTripBarcodeScan = "EndOfTripBarcodeScanNotValid";
        public const string MissingScanData = "MissingScanData";

        //reset password
        public const string GeneralPasswordResetError = "GeneralPasswordResetError";

        //Promotions
        public const string CriteriaHasTooManyParameters = "CriteriaHasTooManyParameters";


        
        //PriceOverride
        public const string PriceOverrideIsNotAllowed = "PriceOverrideIsNotAllowed";
        public const string NewPriceIsNotValid = "NewPriceIsNotValid";
        public const string ThisActionIsNotAllowedForScaleBagException = "ThisActionIsNotAllowedForScaleBagException";

        public const string KeyInLoyaltyCardsNotAllowedFromPos = "KeyInLoyaltyCardsNotAllowedFromPos";
        //"Loyalty cards are not allowed to be keyed in from POS";


        //VouchersMaintenanceService
        public const string VoucherNotFound = "VoucherNotFound";
        // public const string AccessToVoucherDenied = "AccessToVoucherDenied";
        public const string AuthorizationRequiredTender = "AuthorizationRequiredTender";
        public const string InvalidVoucher = "InvalidVoucher";
        public const string VoucherLocked = "VoucherLocked";
        public const string VoucherAlreadyRedeemed = "VoucherAlreadyRedeemed";
        public const string VoucherExpired = "VoucherExpired";
        public const string VoucherNotValidYet = "VoucherNotValidYet";
        public const string VoucherIsNotLocked = "VoucherIsNotLocked";
        public const string VoucherBarcodeError = "VoucherBarcodeError";
        public const string VoucherAlreadyInTransaction = "VoucherAlreadyInTransaction";
        public const string VoucherMustBeFullyRedeemed = "VoucherMustBeFullyRedeemed";
        public const string VoucherNotSupported = "VoucherNotSupported";
        public const string VoucherNotAvailable = "VoucherNotAvailable";
        public const string VoucherInconsistentState = "VoucherInconsistentState";
        public const string InvalidVoucherDatesRange = "InvalidVoucherDatesRange";
        public const string InvalidVoucherDateFormat = "InvalidVoucherDateFormat";
        public const string MatchingVoucherProcessingModeExtractorNotDefined = "Matching VoucherProcessingModeExtractor is not defined";
        public const string ServerIsOffline = "ServerIsOffline";
        public const string ActionNotSupplied = "ActionNotSupplied";
        public const string BarcodeNotSupplied = "BarcodeNotSupplied";
        public const string TransactionExternalIdNotSupplied = "TransactionExternalIdNotSupplied";
        public const string UpdaterTypeNotSupplied = "UpdaterTypeNotSupplied";
        public const string OwnerBusinessUnitNotSupplied = "OwnerBusinessUnitNotSupplied";
        public const string StatusNotSupplied = "StatusNotSupplied";
        public const string BusinessUnitStoreIdNotSupplied = "BusinessUnitStoreIdNotSupplied";
        public const string TouchPointPosIdNotSupplied = "TouchPointPosIdNotSupplied";
        public const string IncorrectStatusValue = "IncorrectStatusValue";
        public const string VoucherMaintenanceActionNotSupplied = "VoucherMaintenanceActionNotSupplied";
        

        public const string UnableCastToVouchersMaintenanceServiceActions =
            "Unable to cast to Constants.Tenders.VouchersMaintenanceServiceActions";

        //DetailedPromotionsLookup
        public const string CriteriaMissing = "CriteriaMissing";
        public const string BusinessUnitMissing = "BusinessUnitMissing";
        public const string TouchPointMissing = "TouchPointMissing";
        public const string ItemMissing = "ItemMissing";

        public const string CustomerRequierd = "CustomerRequierd";
        public const string CustomerOrderRequierd = "CustomerOrderRequierd";
        public const string PartialPaymentExists = "PartialPaymentExists";
        public const string OnlyProhibitPoints = "OnlyProhibitPoints";
        public const string BirthDayValidation = "BirthDayValidation";
        public const string NoPointConvertPromotion = "NoPointConvertPromotion";
        public const string UnexpectedErrorWhileAddingCustomer = "UnexpectedErrorWhileAddingCustomer";


        //Prize Item
        public const string NotEnoughPointsException = "NotEnoughPointsException";
        public const string ScanLoyaltyException = "ScanLoyaltyException";
        public const string ItemCannotBeSoldException = "ItemCannotBeSoldException";


        //Open Gate
        public const string OpenGateTransactionNotFound = "OpenGateTransactionNotFound";
        public const string OpenGateTimeOut = "OpenGateTimeOut";
        public const string OpenGateWrongTill = "OpenGateWrongTill";
        public const string OpenGateAlreadyUsedBarcode = "OpenGateAlreadyUsedBarcode";

        //HappyHourPromotionActive
        public const string HappyHourActiveInfoMissing = "HappyHourActiveInfoMissing";
        public const string HappyHourPromotionIdMissing = "HappyHourPromotionIdMissing";
        public const string HappyHourPromotionMissingActiveItemst = "HappyHourPromotionMissingActiveItemst";
        public const string HappyHourStartDateMissing = "HappyHourStartDateMissing";
        public const string HappyHourStartDateOutOfScope = "HappyHourStartDateOutOfScope";
        public const string HappyHourEndDateOutOfScope = "HappyHourEndDateOutOfScope";
        public const string HappyHourEndDateMissing = "HappyHourEndDateMissing";
        public const string ProRedeemApprovalOpenBalanceNotSufficient = "ProRedeemApprovalOpenBalanceNotSufficient";

        // Subtotal
        public const string CantPerformSubtotalWhileInRescan = "CantPerformSubtotalWhileInRescan";

        //UserMaintenance
        public const string UserMustContainRole = "UserMustContainRole";
        public const string ExternalUserIdAlreadyExistInThisStore = "ExternalUserIdAlreadyExistInThisStore";
        public const string UserCantHaveTwoDifferentExternalUserIdInOneStore = "UserCantHaveTwoDifferentExternalUserIdInOneStore";
        public const string RoleMustHasAnExternalIdDefinition = "RoleMustHasAnExternalIdDefinition";
        public const string InvalidUserExternalIdLength = "InvalidUserExternalIdLength";
        public const string InvalidUserExternalIdFormat = "InvalidUserExternalIdFormat";
        public const string ExternalUserIdCantExistWithNoRoleDefinedInThisStore = "ExternalUserIdCantExistWithNoRoleDefinedInThisStore";

        //Coupon
        public const string CouponNotAllowedInOffline = "CouponNotAllowedInOffline";
        public const string EndDateLessThanStartDate = "EndDateLessThanStartDate";
        public const string CouponNotFound = "CouponNotFound";

        // LMS Customer Promotion
        public const string CustomerPromotionRegistrationFailures = "CustomerPromotionRegistrationFailures";
        public const string CustomerPromotionRequestMissingDetails = "CustomerPromotionRequestMissingDetails";
        public const string CustomerPromotionInvalidRequest = "CustomerPromotionInvalidRequest";

        // Email sign up & reset password verification
        public const string SmtpClientSendFailed = "SmtpClientSendFailed";
        public const string SignupRequiredActivation = "SignupRequiredActivation";

        //Catalina
        public const string InvalidCatalinaConfigurationLookupRequest = "InvalidCatalinaConfigurationLookupRequest";

        //FiscalRT
        public const string InvalidFiscalRTConfigurationLookupRequest = "InvalidFiscalRTConfigurationLookupRequest";
        public const string MissingFiscalRTConfiguration = "MissingFiscalRTConfiguration";
        public const string FiscalRtNotInitialized = "FiscalRtNotInitialized";
        public const string FiscalRtTokenNotInitialized = "FiscalRtTokenNotInitialized";
        public const string FiscalRtGenericError = "FiscalRtGenericError";
        public const string FiscalRtCommunicationError = "FiscalRtCommunicationError";
        public const string FiscalRtInvalidDataError = "FiscalRtInvalidDataError";
        public const string FiscalRtFiscalDayNotOpenError = "FiscalRtFiscalDayNotOpenError";
        public const string MissingTokenSignature = "MissingTokenSignature";
        public const string MissingFiscalDataForReturnTransaction = "MissingFiscalDataForReturnTransaction";
        public const string FiscalDataNotFoundInLinkedTransaction = "FiscalDataNotFoundInLinkedTransaction";
        public const string FiscalLotteryFailedDataPatternValidation = "FiscalLotteryFailedDataPatternValidation";

        //Temporary Price Reduction
        public const string CatalogPriceNotFoundException = "CatalogPriceNotFoundException";

        [SuppressMessage("ReSharper", "InconsistentNaming")]
        public struct FiscalRT
        {
            public const int RT_COMMAND_QUEUED = -1;
            public const int RT_SUCCESS = 0;
            public const int RT_TOKEN_NOT_INITIALIZED = 10001;
            public const int RT_AUTHENTICATION_ERROR = 10002;
            public const int RT_INVALID_DATA = 10003;
            public const int RT_NOT_INITIALIZED = 10004;
            public const int RT_REGISTER_STATUS_DAY_NOT_OPEN = 0;
        }

        //FastPay
        public const string MissingLoyaltyId = "MissingLoyaltyId";
        public const string MissingFastPayEOTBarcode = "MissingFastPayEOTBarcode";
        public const string NotValidEOTFastPayBarcode = "NotValidEOTFastPayBarcode";
        public const string SuspendedTransactionNotFound = "SuspendedTransactionNotFound";
        public const string MissingEPSDataOnRequest = "MissingEPSDataOnRequest";
        public const string RescanRequiredMessage = "FastPayFailed";
        public const string SuspendedTransactionAndMoveToPOS = "SuspendedTransactionAndMoveToPOS";
        public const string MissingUserNameConfiguration = "MissingUserNameConfiguration";
        public const string MissingUserConfiguration = "MissingUserConfiguration";
        public const string PaymentFailed = "PaymentFailed";
        public const string SSCFastPayOfflineTransactionMessage = "SSCFastPayOfflineTransactionMessage";
        public const string VoidFailed = "VoidFailed";
        // Invoice
        public const string LoyaltyCardNotAllowedAfterInvoice = "LoyaltyCardNotAllowedAfterInvoice";


        // Tenders
        public const string MissingTokenForPreAuthorizationPayment = "MissingTokenForPreAuthorizationPayment";

        //Repeat Line
        public const string CanNotRepeatDepartmentSale = "CanNotRepeatDepartmentSale";

        //Product Configuration
        public const string ProductConfigurationExceptionErrorCode = "ProductConfigurationException";
    }
}
