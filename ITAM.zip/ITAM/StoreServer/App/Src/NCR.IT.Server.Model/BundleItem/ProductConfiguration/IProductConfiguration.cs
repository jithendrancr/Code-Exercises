﻿using Retalix.StoreServices.Model.Infrastructure.DataMovement;

namespace NCR.IT.Server.Model.BundleItem
{
    public interface IProductConfiguration //: IMovable, INamedObject
    {
        int Id { get; set; }
        string Code { get; set; }
        string Description { get; set; }
    }
}
