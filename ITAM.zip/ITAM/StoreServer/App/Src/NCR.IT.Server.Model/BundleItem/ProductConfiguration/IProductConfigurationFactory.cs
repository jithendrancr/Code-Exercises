﻿namespace NCR.IT.Server.Model.BundleItem
{
    /// <summary>
    /// An abstract factory that hadles the reation of  <see cref="IBundleItem"/>.
    /// 
    /// </summary>
    public interface IProductConfigurationFactory
    {
        IProductConfiguration CreateProductConfiguration(int Id = 0, string Code = "", string Descrition = "");
    }                                 
}                                     
